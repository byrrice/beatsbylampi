//
//  ViewController.swift
//  BeatsByLampi
//
//  Created by Savita Medlang on 4/20/19.
//  Copyright © 2019 Savita Medlang. All rights reserved.
//

import UIKit
import CoreBluetooth
import MediaPlayer
import SpotifyKit
import Alamofire


import AVFoundation



class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate {
    let SpotifyClientID = "3ae06156b48548da999cbf24346581dd"
    let SpotifyClientSecret="62691030538e4d77abce9a875a6f612d"
    let SpotifyRedirectURI="spotify-ios-quick-start://spotify-login-callback"
    let delegate = UIApplication.shared.delegate as! AppDelegate
    var duration: Double = 0
    var hueTimer: Timer = Timer.init()
    var sectionTimer: Timer = Timer.init()
    var white: Bool = true
    
    var sectionIndex:Int=0
    @IBOutlet weak var searchField: UITextField!

    @IBOutlet weak var songView: UITextView!
    var player: AVAudioPlayer?
    var accessToken: String!
    var goUp: Bool = true
    
    var buttonArr:[UIButton] = []
    
    @IBOutlet weak var searchResultsView: UITextView!
    
    @IBOutlet weak var button1: UIButton!
    
    @IBOutlet weak var button2: UIButton!
    //    @IBOutlet weak var volumeControl: GradientSlider!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var button5: UIButton!
    
    @IBOutlet weak var playButton: UIButton!
    var buttons: [UIButton]=[]
    var bluetoothManager: CBCentralManager! = CBCentralManager()
    var devicePeripheral: CBPeripheral!
    var discovered: Bool = false
    var updatePending: Bool = false
    var connected:Bool=false
    var numberCharacteristic: CBCharacteristic!
    var hsvCharacteristic: CBCharacteristic!
    var onOffCharacteristic: CBCharacteristic!
    var brightnessCharacteristic: CBCharacteristic!
    var songNameCharacteristic: CBCharacteristic!
    var powerIsOn:Bool = true
    
//    let DEVICE_NAME="LAMPI b827ebafb9ca"
    
    
    let DEVICE_NAME="LAMPI b827eb3b4f75"
    
    
    var hueVal: Float=1.0
    var satVal: Float=1.0
    var brightnessVal: Float=1.0
    var sendUpdate: Bool = true

    
//    Savi lampi - let SOME_NUMBER_UUID = "7a4b0001-999f-4717-b63a-066e06971f59"
    let SOME_NUMBER_UUID="934884C1-E107-D06E-97D1-EF262D4B58F3"
    let OUR_SERVICE_UUID="0001A7D3-D8A4-4FEA-8174-1736E808C066"
    let ON_OFF_UUID = "0004A7D3-D8A4-4FEA-8174-1736E808C066"
    let HSV_UUID="0002A7D3-D8A4-4FEA-8174-1736E808C066"
    let BRIGHTNESS_UUID="0003A7D3-D8A4-4FEA-8174-1736E808C066"
    let SONG_NAME_UUID="0005A7D3-D8A4-4FEA-8174-1736E808C066"
    
    var spotifyManager : SpotifyManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        delegate.currentSongIndex = -1
        self.accessToken=delegate.accessToken
        spotifyManager=delegate.spotifyManager
        searchResultsView.isHidden=true
        bluetoothManager = CBCentralManager(delegate: self, queue: nil)
        buttons = [button1, button2, button3, button4, button5]
        disableButtons()
    }
    
    func getAudioFeatures(index: Int){
        delegate.currentSongIndex=index
        songView.text=delegate.trackArr[index].songTitle
        let group = DispatchGroup()
        group.enter()
        
        DispatchQueue.main.async {
            AF.request("https://api.spotify.com/v1/audio-analysis/" + self.delegate.trackArr[self.delegate.currentSongIndex].trackURI, parameters: nil, encoding: URLEncoding.default, headers: ["Authorization" : self.delegate.accessToken ], interceptor: nil).responseJSON(completionHandler: { response in
                let dict = response.value as! NSDictionary
                
                if let status = response.response?.statusCode {
                    switch(status){
                    case 200:
                        print("example success")
                        self.delegate.trackArr[self.delegate.currentSongIndex].sections=dict.object(forKey: "sections") as! NSArray
//                        self.delegate.trackArr[self.delegate.currentSongIndex].energy = energy!.floatValue
                        

                    default:
                        print("error with response status: \(status)")
                    }
                }
                
                AF.request("https://api.spotify.com/v1/audio-features/" + self.delegate.trackArr[index].trackURI, parameters: nil, encoding: URLEncoding.default, headers: ["Authorization" : self.delegate.accessToken], interceptor: nil).responseJSON(completionHandler: { response in
                    
                    self.delegate.trackArr[index].duration_s = (((response.value as! NSDictionary).object(forKey: "duration_ms") as? Double)!)
                    self.delegate.trackArr[index].duration_s = self.delegate.trackArr[index].duration_s/1000
                    
                    let loudness = (response.value as! NSDictionary).object(forKey: "loudness") as? NSNumber
                    self.delegate.trackArr[self.delegate.currentSongIndex].loudness = loudness!.floatValue
                    let danceability = (response.value as! NSDictionary).object(forKey: "danceability") as? NSNumber
                    self.delegate.trackArr[self.delegate.currentSongIndex].danceability = danceability!.floatValue
                    let valence = (response.value as! NSDictionary).object(forKey: "valence") as? NSNumber
                    self.delegate.trackArr[self.delegate.currentSongIndex].valence = valence!.floatValue
                    let energy = (response.value as! NSDictionary).object(forKey: "energy") as? NSNumber
                    self.delegate.trackArr[self.delegate.currentSongIndex].energy = energy!.floatValue


                    group.leave()

                })
            })
        }
        group.notify(queue: .main) {
            self.playButton.isEnabled=true
        }
    }
    
    func disableButtons(){
        for button in buttons {
            button.isEnabled=false
        }
        self.playButton.isEnabled=false
    }
    
    @IBAction func pauseSongPressed(_ sender: Any) {
        self.stopSong()
    }
    
    func stopSong(){
        self.hueTimer.invalidate()
        API.stopSong()
    }
    
    @IBAction func searchPressed(_ sender: Any) {

        //resets the track array
        stopSong()
        self.view.endEditing(true)
//        self.delegate.trackArr=[]
        var count=0
        let group = DispatchGroup()
        group.enter()
        DispatchQueue.main.async {
            self.spotifyManager.find(SpotifyTrack.self, self.searchField.text!) { tracks in
                // Tracks is a [SpotifyTrack] array
                for track in tracks {
                    if count < 4 {
                        let newTrack = Track()
                        let tempIndex = track.uri.index(track.uri.startIndex, offsetBy: 0)
                        newTrack.contextURI = String(track.uri[tempIndex...])
                        let indexStartOfText = track.uri.index(track.uri.startIndex, offsetBy: 14)
                        newTrack.trackURI=String(track.uri[indexStartOfText...])
                        newTrack.songTitle=track.name
                        newTrack.artistName = track.artist.name
                        
                        self.delegate.trackArr[count] = newTrack
                        
                        self.buttons[count].isHidden=false
                        self.buttons[count].setTitle(track.name + " by " + track.artist.name, for: UIControl.State.normal)
                    }
                    count=count+1
                }
                group.leave()
            }
        }

        group.notify(queue: .main) {
            for button in self.buttons {
                button.isEnabled=true
            }
        }
    }
    
    @IBAction func button0Pressed(_ sender: Any) {
        self.getAudioFeatures(index: 0)
        self.delegate.currentSongIndex=0
    }
    
    @IBAction func button1Pressed(_ sender: Any) {
        self.getAudioFeatures(index: 1)
        self.delegate.currentSongIndex=1
    }
    
    @IBAction func button2Pressed(_ sender: Any) {
        self.getAudioFeatures(index: 2)
        self.delegate.currentSongIndex=2
    }
    
    @IBAction func button3Pressed(_ sender: Any) {
        self.getAudioFeatures(index: 3)
        self.delegate.currentSongIndex=3
    }
    
    @IBAction func button4Pressed(_ sender: Any) {
        self.getAudioFeatures(index: 4)
        self.delegate.currentSongIndex=4
    }
    
    
    @IBAction func playButtonPressed(_ sender: Any) {
        self.hueTimer.invalidate()
        self.delegate.trackArr[self.delegate.currentSongIndex].printInformation()
        API.playSong(contextURI: self.delegate.trackArr[delegate.currentSongIndex].contextURI)
        self.updateSongName()
        self.startBeats(sectionIndex: 0)
    }
    
    @objc func changeHue () {
        
        if hueVal > 0.9 {
            goUp = false
        }
        if hueVal < 0.1 {
            goUp = true
        }
        if goUp {
            hueVal = hueVal + 0.1
        }else {
            hueVal = hueVal - 0.1
        }
        updateColors()
    }
    
    func startBeats(sectionIndex: Int){
        self.hueTimer = Timer.init()
        let currentTrack = self.delegate.trackArr[self.delegate.currentSongIndex]
        let s: NSDictionary = currentTrack.sections[sectionIndex] as! NSDictionary
        self.duration = s.object(forKey: "duration") as! Double
        let t: NSNumber = s.object(forKey: "tempo") as! NSNumber
        let l: NSNumber = s.object(forKey: "loudness") as! NSNumber
        var loudness: Float = Float(l)
        var tempo: Float = Float(t)
        tempo = 60/tempo
        print("Tempo: " + String(tempo))
        print(loudness)
        
        if currentTrack.danceability > 0.6 {
            tempo = tempo/2
        }
        self.brightnessVal = (60 + loudness)/60
//        self.brightnessVal = currentTrack.energy
        self.hueVal = 0
        
        self.hueTimer = Timer.scheduledTimer(timeInterval: TimeInterval(tempo), target: self, selector:#selector(self.changeHue), userInfo: nil, repeats: true)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            self.hueTimer.invalidate()
            if (sectionIndex < currentTrack.sections.count-1){
                self.startBeats(sectionIndex: sectionIndex+1)
            }else{
                self.stopSong()
            }
        }
    }
    
    
//    func startBeats(){
        //** WORKING SINGLE TEMPO Beats *//
//        self.timer = Timer.init()
//        let currentTrack = self.delegate.trackArr[self.delegate.currentSongIndex]
//        let s: NSDictionary = currentTrack.sections[0] as! NSDictionary
//        self.duration = s.object(forKey: "duration") as! Double
//        let t: NSNumber = s.object(forKey: "tempo") as! NSNumber
//
//        var tempo: Float = Float(t)
//        tempo = 60/tempo
//
//        if currentTrack.danceability > 0.6 {
//            tempo = tempo/2
//        }
//        self.brightnessVal = currentTrack.energy
//        self.hueVal = 0
//
//        print("Brightness: " + String(self.brightnessVal))
//        print("Tempo: " + String(tempo))
//
//        self.hueTimer = Timer.scheduledTimer(timeInterval: TimeInterval(tempo), target: self, selector:#selector(self.changeHue), userInfo: nil, repeats: true)
//
//        DispatchQueue.main.asyncAfter(deadline: .now() + self.delegate.trackArr[self.delegate.currentSongIndex].duration_s) {
//            self.hueTimer.invalidate()
//        }
        
        /** working single Tempo *///
        
        
//    }
    
    
    


    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        print("didUpdateStateCalled")
        if central.state == .poweredOn {
            let services:NSArray = [CBUUID.init(string: OUR_SERVICE_UUID)]
            bluetoothManager.scanForPeripherals(withServices: services as? [CBUUID], options: nil)
        }
    }
    
    func centralManager (_ central: CBCentralManager, didDiscover devicePeripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber){
        print("did Discover called")

        print(devicePeripheral.name)
        
        if devicePeripheral.name == DEVICE_NAME && !self.discovered {
            self.devicePeripheral = devicePeripheral
            self.discovered=true
            devicePeripheral.delegate=self
            print("discover")

            
            bluetoothManager.stopScan() // ?
            bluetoothManager.connect(devicePeripheral, options: nil)
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral){
        peripheral.delegate=self
        self.connected = true
        print("connected")

        if peripheral.services != nil{
            self.peripheral(peripheral, didDiscoverServices: nil)
        }else{
            peripheral.discoverServices(nil)
        }
    }
    
    func centralManager(_ central: CBCentralManager, didFailToConnectPeripheral devicePeripheral: CBPeripheral){
        print("failed to connect")
        
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?){
     
        print("discover")
        if let error = error {
            return
        }
        
        for service in peripheral.services! {
            //            if service.uuid.isEqual([CBUUID.init(string:OUR_SERVICE_UUID)]){
            //            if service.uuid.debugDescription.isEqual(OUR_SERVICE_UUID){
            if service.uuid.debugDescription.caseInsensitiveCompare(OUR_SERVICE_UUID) == .orderedSame {
                peripheral.discoverCharacteristics(nil, for: service)
            }
        }
    }
    
    func peripheral (_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?){
        
        for characteristic in service.characteristics! {
            if characteristic.uuid.debugDescription.caseInsensitiveCompare(SOME_NUMBER_UUID) == .orderedSame {
                self.numberCharacteristic = characteristic;
                
            }
            
            if characteristic.uuid.debugDescription.caseInsensitiveCompare(HSV_UUID) == .orderedSame {
                self.hsvCharacteristic = characteristic;
                self.devicePeripheral.readValue(for: characteristic)
                self.devicePeripheral.setNotifyValue(true, for: characteristic)
            }
            if characteristic.uuid.debugDescription.caseInsensitiveCompare(BRIGHTNESS_UUID) == .orderedSame {
                self.brightnessCharacteristic = characteristic;
                self.devicePeripheral.readValue(for: characteristic)
                self.devicePeripheral.setNotifyValue(true, for: characteristic)
            }
            if characteristic.uuid.debugDescription.caseInsensitiveCompare(ON_OFF_UUID) == .orderedSame {
                self.onOffCharacteristic = characteristic;
                self.devicePeripheral.readValue(for: characteristic)
                self.devicePeripheral.setNotifyValue(true, for: characteristic)
            }
            if characteristic.uuid.debugDescription.caseInsensitiveCompare(SONG_NAME_UUID) == .orderedSame {
                self.songNameCharacteristic = characteristic;
                self.devicePeripheral.readValue(for: characteristic)
                self.devicePeripheral.setNotifyValue(true, for: characteristic)
            }
            
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?){
        if characteristic.uuid.debugDescription.caseInsensitiveCompare(HSV_UUID) == .orderedSame {
//                        hueVal = Float(characteristic.value![0]) / 255;
//                        satVal = Float(characteristic.value![1]) / 255;
//                        sendUpdate=false
//                        updateColors()
        }
        else if characteristic.uuid.debugDescription.caseInsensitiveCompare(BRIGHTNESS_UUID) == .orderedSame {
//                        brightnessVal = Float(characteristic.value![0]) / 255;
//                        sendUpdate=false
//                        updateColors()
        }
        else if characteristic.uuid.debugDescription.caseInsensitiveCompare(ON_OFF_UUID) == .orderedSame {
//                        if Float(characteristic.value![0]) == 0 {
//                            self.powerIsOn = false
//                        }else{
//                            self.powerIsOn = true
//                        }
//                        sendUpdate=false
//                        updateColors()
        }
        
    }
    
    func updateSongName(){
//        let song_name_date: NSData(bytes)
        let str = delegate.trackArr[delegate.currentSongIndex].songTitle + "\n" + delegate.trackArr[delegate.currentSongIndex].artistName
        print(str)
        print(songNameCharacteristic)
        
        let song_name_data: Data = str.data(using: .utf8)!
        self.devicePeripheral.writeValue(song_name_data as Data, for: songNameCharacteristic!, type: CBCharacteristicWriteType.withResponse)
        let d=NSData(bytes: [0x01], length: 1)
        self.devicePeripheral.writeValue(d as Data, for: onOffCharacteristic, type: CBCharacteristicWriteType.withResponse)

    }
    
    func updateColors(){
        
        //        powerButton.tintColor=UIColor.init(hue: CGFloat(hueVal), saturation: CGFloat(satVal), brightness:1.0, alpha: 1.0)
        //        var new_value = hueVal
        if self.connected && !self.updatePending && sendUpdate{
            self.updatePending=true
            let hsv_data: NSData = NSData(bytes: [UInt8(hueVal * 255), UInt8(satVal * 255), UInt8(255)] , length: 3)
            self.devicePeripheral.writeValue(hsv_data as Data, for: hsvCharacteristic, type: CBCharacteristicWriteType.withResponse)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { // Change `2.0` to the desired number of seconds.
                self.updatePending=false
            }
            let brightness_data = NSData(bytes: [UInt8(brightnessVal * 255)], length: 1)
            self.devicePeripheral.writeValue(brightness_data as Data, for: brightnessCharacteristic, type: CBCharacteristicWriteType.withResponse)
            
            
        } else if !sendUpdate {
            sendUpdate = true
        }
        
    }
}
