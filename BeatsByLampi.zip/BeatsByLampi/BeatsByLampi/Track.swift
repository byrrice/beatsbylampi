//
//  Track.swift
//  BeatsByLampi
//
//  Created by Savita Medlang on 4/22/19.
//  Copyright © 2019 Savita Medlang. All rights reserved.
//

import Foundation
import UIKit

class Track {
    var songTitle: String!
    var artistName: String!
    var button: UIButton!
    var trackURI: String!
    var tempo: Float!
    var key: Int!
    var duration_s: Double!
    var energy: Float!
    var danceability: Float!
    var loudness: Float!
    var timeSignature: Int!
    var sections:NSArray!
    var valence: Float!
    var contextURI: String!
    
    
    init(){

    }
    
    func printInformation(){
//        print ("duration: " + String(self.duration_s) + ", loudness: " + String(self.loudness) + ", danceability: " + String(self.danceability) + ", energy: " + String(self.energy))
    }

}
