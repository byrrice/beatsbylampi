//
//  API.swift
//  BeatsByLampi
//
//  Created by Savita Medlang on 5/4/19.
//  Copyright © 2019 Savita Medlang. All rights reserved.
//

import Foundation
import Alamofire
//let SpotifyClientID = "3ae06156b48548da999cbf24346581dd"
let delegate = UIApplication.shared.delegate as! AppDelegate

class API {

    static let delegate = UIApplication.shared.delegate as! AppDelegate

    static func setAuthentication(){
        
    }
    
    static func stopSong (){
        
        AF.request("https://api.spotify.com/v1/me/player/pause", method: .put, parameters: nil, encoding:  JSONEncoding.default, headers: ["Authorization" : delegate.accessToken ], interceptor: nil).responseJSON(completionHandler: { response in
            
            if let status = response.response?.statusCode {
                switch(status){
                case 204:
                    print("pause success")
                    
                default:
                    print (response)
                    print("pause error with response status: \(status)")
                }
            }
        })
    }

    
    static func playSong(contextURI: String){
        print(contextURI)
//        let parameters: [String: String] = ["context_uri": contextURI]
        let parameters:[String: [String]]=["uris": [contextURI, contextURI]]
        
        AF.request("https://api.spotify.com/v1/me/player/play", method: .put, parameters: parameters, encoding:  JSONEncoding.default, headers: ["Authorization" : delegate.accessToken ], interceptor: nil).responseJSON(completionHandler: { response in
            
            if let status = response.response?.statusCode {
                switch(status){
                case 204:
                    print("play success")

                default:
                    print (response)
                    print("error with response status: \(status)")
                }
            }
        })
    }
    
    
}
