//
//  AppDelegate.swift
//  BeatsByLampi
//
//  Created by Savita Medlang on 4/20/19.
//  Copyright © 2019 Savita Medlang. All rights reserved.
//

import UIKit
import SpotifyKit
let SpotifyClientID = "3ae06156b48548da999cbf24346581dd"
let SpotifyClientSecret="560e4254a5f94f33b788f5a2f9c9d2e8"
import Alamofire


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var currentSongIndex:Int = -1
    var trackArr: [Track]=[Track(), Track(), Track(), Track()]

    var window: UIWindow?
    let accessToken = "Bearer BQBdf2AZZF9aGwIGPINGqIsth0O-dZtrfCSdhX33ybPZQnRxdEYhS4th2LtCURC_LJb5ZIVi5oBGE8VpX1_Ah0vis8bXwL-bm9IXb6aoTtL4NwwVjf9ud5gis_hVe5StZWK-4Nq1yEOHk2ZycBwVjDrTXNLxgIA-ND2eZ63hb-yNjNe3T3duGjvxE6gCcWKK-pwcEVjOzMRTHGv54jX9XG46eMbMc0VGaDoxRZPD25RZHbFM8cogQ9dO1_yqiDTLHV5d"

    let spotifyManager = SpotifyManager(with:
        SpotifyManager.SpotifyDeveloperApplication(
            clientId:     SpotifyClientID,
            clientSecret: SpotifyClientSecret,
            redirectUri: "spotify-ios-quick-start://spotify-login-callback"
        )
    )
    
    
    
    func application(_ application: UIApplication, handleOpen url: URL) -> Bool {
                spotifyManager.saveToken(from: url)
        print(url)
        print("Handle url")
        return true
    }
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
                spotifyManager.authorize()
        return true
    }
    
    
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
//        API.stopSong()

        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    
}

